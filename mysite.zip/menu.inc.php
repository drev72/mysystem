  <nav>
                <ul>
                    <li><a href="#"> Обо мне </a></li>
                    <li><a href="#"> Мои работы	 </a></li>
                    <li><a href="#"> Контакты </a></li>
                </ul>    
            </nav>