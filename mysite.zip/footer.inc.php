<div class="footer">
            <h2>Контакты: drev72</h2>
        </div>