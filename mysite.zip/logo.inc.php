                <div class="logo"> 
                <img src="img/1.png" alt="php">
                </div>                                                 
        