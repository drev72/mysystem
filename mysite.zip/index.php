<?php 
 $p = 'Добрый день! Это пробная работа по PHP';
?>

<?php 
 $name = 'Андрей';
 $surname = 'Бегишев';
 $city = 'Новосибирск';
 $age = 49;
?>

<?php
include 'main.php';
?>